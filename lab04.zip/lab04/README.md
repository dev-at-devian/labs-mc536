# Aluno
* 236773: Igor Gabriel Cavalcante de Carvalho Borges

## Tarefa sobre Consultas SQL no NHANES

[Tarefa](./notebook/lab04-sql-advanced.ipynb)
